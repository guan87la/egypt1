import React, { useState, useMemo } from 'react';
import { motion, AnimatePresence } from 'motion/react';
import { 
  Calendar, 
  Phone, 
  MapPin, 
  Utensils, 
  Bus, 
  Plane, 
  Hotel, 
  ShoppingBag,
  ChevronRight,
  Star,
  Clock,
  BookOpen,
  Navigation as NavIcon,
  AlertCircle
} from 'lucide-react';
import { ITINERARY, INFO, DayPlan, Activity } from './data/itinerary';

const ActivityIcon = ({ type }: { type: string }) => {
  switch (type) {
    case 'attraction': return <MapPin className="w-5 h-5 text-[#5D4037]" />;
    case 'restaurant': return <Utensils className="w-5 h-5 text-[#5D4037]" />;
    case 'transport': return <Bus className="w-5 h-5 text-[#5D4037]" />;
    case 'hotel': return <Hotel className="w-5 h-5 text-[#5D4037]" />;
    case 'shopping': return <ShoppingBag className="w-5 h-5 text-[#5D4037]" />;
    default: return <AlertCircle className="w-5 h-5 text-[#5D4037]" />;
  }
};

interface ActivityCardProps {
  activity: Activity;
  key?: string;
}

const ActivityCard = ({ activity }: ActivityCardProps) => {
  const [isExpanded, setIsExpanded] = useState(false);
  const isTransport = activity.type === 'transport';

  return (
    <motion.div 
      layout
      className={`${
        isTransport 
          ? 'bg-[#EFEBE9]/40 border-dashed border-[#D7CCC8] shadow-none' 
          : 'bg-white border-[#E0D7D1] shadow-sm'
      } rounded-2xl border overflow-hidden mb-4 transition-colors`}
    >
      <div 
        className={`p-4 flex items-start gap-4 cursor-pointer ${isTransport ? 'py-3' : ''}`}
        onClick={() => setIsExpanded(!isExpanded)}
      >
        <div className={`mt-1 p-2 rounded-xl ${isTransport ? 'bg-white' : 'bg-[#FAF7F2]'}`}>
          <ActivityIcon type={activity.type} />
        </div>
        <div className="flex-1">
          <div className="flex justify-between items-start">
            <h3 className={`font-medium leading-tight ${isTransport ? 'text-[#8D6E63] text-sm' : 'text-[#3D2B1F]'}`}>
              {activity.title}
            </h3>
            {activity.time && <span className="text-xs font-mono text-[#A1887F]">{activity.time}</span>}
          </div>
          {!isTransport && activity.description && (
            <p className="text-sm text-[#6D4C41] mt-1 line-clamp-2">{activity.description}</p>
          )}
          {isTransport && activity.description && (
            <p className="text-[11px] text-[#8D6E63] mt-0.5">{activity.description}</p>
          )}
        </div>
        <ChevronRight className={`w-5 h-5 text-[#D7CCC8] transition-transform ${isExpanded ? 'rotate-90' : ''}`} />
      </div>

      <AnimatePresence>
        {isExpanded && (
          <motion.div 
            initial={{ height: 0, opacity: 0 }}
            animate={{ height: 'auto', opacity: 1 }}
            exit={{ height: 0, opacity: 0 }}
            className="px-4 pb-4 border-t border-[#FAF7F2] pt-4 space-y-4"
          >
            {activity.story && (
              <div className="space-y-1">
                <div className="flex items-center gap-1.5 text-[#A1887F]">
                  <BookOpen className="w-3.5 h-3.5" />
                  <span className="text-[11px] uppercase tracking-wider font-semibold">景點故事</span>
                </div>
                <p className="text-sm text-[#5D4037] leading-relaxed italic">{activity.story}</p>
              </div>
            )}

            {activity.highlights && (
              <div className="grid grid-cols-1 gap-3">
                {activity.highlights.mustEat && (
                  <div className="bg-[#EFEBE9] p-3 rounded-xl border border-[#D7CCC8]">
                    <span className="text-[10px] text-[#8D6E63] font-bold uppercase block mb-1">必吃美食</span>
                    <p className="text-sm text-[#3D2B1F] font-medium">{activity.highlights.mustEat.join('、')}</p>
                  </div>
                )}
                {activity.highlights.mustOrder && (
                  <div className="bg-[#EFEBE9] p-3 rounded-xl border border-[#D7CCC8]">
                    <span className="text-[10px] text-[#8D6E63] font-bold uppercase block mb-1">必點菜單</span>
                    <p className="text-sm text-[#3D2B1F] font-medium">{activity.highlights.mustOrder.join('、')}</p>
                  </div>
                )}
                {activity.highlights.mustBuy && (
                  <div className="bg-[#EFEBE9] p-3 rounded-xl border border-[#D7CCC8]">
                    <span className="text-[10px] text-[#8D6E63] font-bold uppercase block mb-1">必買伴手禮</span>
                    <p className="text-sm text-[#3D2B1F] font-medium">{activity.highlights.mustBuy.join('、')}</p>
                  </div>
                )}
                {activity.highlights.bookingCode && (
                  <div className="bg-[#D7CCC8]/30 p-3 rounded-xl border border-[#D7CCC8]">
                    <span className="text-[10px] text-[#5D4037] font-bold uppercase block mb-1">重要資訊 / 預約</span>
                    <p className="text-sm text-[#3D2B1F] font-bold">{activity.highlights.bookingCode}</p>
                  </div>
                )}
              </div>
            )}

            {activity.tips && (
              <div className="space-y-2">
                <div className="flex items-center gap-1.5 text-[#A1887F]">
                  <Star className="w-3.5 h-3.5" />
                  <span className="text-[11px] uppercase tracking-wider font-semibold">小撇步</span>
                </div>
                <ul className="space-y-1.5">
                  {activity.tips.map((tip, i) => (
                    <li key={i} className="text-sm text-[#5D4037] flex items-start gap-2">
                      <span className="w-1 h-1 rounded-full bg-[#D7CCC8] mt-2 shrink-0" />
                      {tip}
                    </li>
                  ))}
                </ul>
              </div>
            )}
          </motion.div>
        )}
      </AnimatePresence>
    </motion.div>
  );
};

const DaySelector = ({ days, activeIndex, onChange }: { days: DayPlan[], activeIndex: number, onChange: (i: number) => void }) => {
  return (
    <div className="flex gap-3 overflow-x-auto px-6 pb-4 scrollbar-hide">
      {days.map((day, i) => (
        <button
          key={i}
          onClick={() => onChange(i)}
          className={`shrink-0 flex flex-col items-center justify-center w-14 h-16 rounded-2xl transition-all ${
            activeIndex === i 
              ? 'bg-[#3D2B1F] text-white shadow-lg shadow-[#3D2B1F]/20' 
              : 'bg-white text-[#A1887F] border border-[#E0D7D1]'
          }`}
        >
          <span className="text-[10px] font-medium uppercase">{day.date.split('/')[0]}月</span>
          <span className="text-lg font-bold leading-none">{day.date.split('/')[1]}</span>
        </button>
      ))}
    </div>
  );
};

export default function App() {
  const [activeTab, setActiveTab] = useState<'itinerary' | 'flights' | 'hotels' | 'emergency'>('itinerary');
  const [activeDayIndex, setActiveDayIndex] = useState(0);

  const activeDay = useMemo(() => ITINERARY[activeDayIndex], [activeDayIndex]);

  const renderContent = () => {
    switch (activeTab) {
      case 'itinerary':
        return (
          <motion.div 
            key="itinerary"
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            className="space-y-6"
          >
            <DaySelector 
              days={ITINERARY} 
              activeIndex={activeDayIndex} 
              onChange={setActiveDayIndex} 
            />

            <div className="px-6">
              <div className="mb-6">
                <h2 className="text-xl font-medium text-[#3D2B1F]">{activeDay.title}</h2>
                <div className="flex items-center gap-2 text-[#A1887F] mt-1">
                  <Clock className="w-3.5 h-3.5" />
                  <span className="text-xs">{activeDay.activities.length} 個行程點</span>
                </div>
              </div>

              <div className="space-y-2">
                {activeDay.activities.map((activity) => (
                  <ActivityCard key={activity.id} activity={activity} />
                ))}
              </div>
            </div>
          </motion.div>
        );
      case 'flights':
        return (
          <motion.div 
            key="flights"
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            className="px-6 space-y-8"
          >
            <section>
              <h3 className="text-xs font-bold uppercase tracking-widest text-[#A1887F] mb-4 flex items-center gap-2">
                <Plane className="w-4 h-4" /> 航班資訊
              </h3>
              <div className="space-y-3">
                {INFO.flights.map((f, i) => (
                  <div key={i} className="bg-white p-4 rounded-2xl border border-[#E0D7D1] shadow-sm">
                    <div className="flex justify-between items-center mb-2">
                      <span className="text-sm font-bold text-[#3D2B1F]">{f.route}</span>
                      <span className="text-[10px] font-mono bg-[#FAF7F2] px-2 py-0.5 rounded text-[#8D6E63]">{f.code}</span>
                    </div>
                    <div className="flex items-center gap-2 text-xs text-[#6D4C41]">
                      <Clock className="w-3 h-3" /> {f.time}
                    </div>
                  </div>
                ))}
              </div>
            </section>
          </motion.div>
        );
      case 'hotels':
        return (
          <motion.div 
            key="hotels"
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            className="px-6 space-y-8"
          >
            <section>
              <h3 className="text-xs font-bold uppercase tracking-widest text-[#A1887F] mb-4 flex items-center gap-2">
                <Hotel className="w-4 h-4" /> 住宿資訊
              </h3>
              <div className="space-y-3">
                {INFO.accommodations.map((a, i) => (
                  <div key={i} className="bg-white p-4 rounded-2xl border border-[#E0D7D1] shadow-sm">
                    <div className="flex justify-between items-center mb-1">
                      <span className="text-sm font-bold text-[#3D2B1F]">{a.name}</span>
                      <span className="text-[10px] text-[#A1887F]">{a.date}</span>
                    </div>
                    <p className="text-xs text-[#6D4C41]">{a.address}</p>
                  </div>
                ))}
              </div>
            </section>
          </motion.div>
        );
      case 'emergency':
        return (
          <motion.div 
            key="emergency"
            initial={{ opacity: 0, y: 10 }}
            animate={{ opacity: 1, y: 0 }}
            className="px-6 space-y-8"
          >
            <section>
              <h3 className="text-xs font-bold uppercase tracking-widest text-[#A1887F] mb-4 flex items-center gap-2">
                <Phone className="w-4 h-4" /> 緊急聯絡
              </h3>
              <div className="grid grid-cols-1 gap-2">
                {INFO.emergency.map((e, i) => (
                  <a 
                    key={i} 
                    href={`tel:${e.number.replace(/[^0-9+]/g, '')}`}
                    className="flex justify-between items-center bg-[#EFEBE9]/50 p-4 rounded-2xl border border-[#D7CCC8]/50"
                  >
                    <span className="text-sm text-[#5D4037] font-medium">{e.label}</span>
                    <span className="text-sm font-bold text-[#8D6E63]">{e.number}</span>
                  </a>
                ))}
              </div>
            </section>
          </motion.div>
        );
      default:
        return null;
    }
  };

  return (
    <div className="min-h-screen bg-[#FAF7F2] text-[#3D2B1F] font-sans selection:bg-[#EFEBE9]">
      {/* Header */}
      <header className="sticky top-0 z-30 bg-[#FAF7F2]/80 backdrop-blur-md px-6 pt-8 pb-4">
        <div className="flex justify-between items-end">
          <div>
            <h1 className="text-3xl font-serif font-light tracking-tight">埃及之旅</h1>
            <p className="text-xs text-[#8D6E63] uppercase tracking-[0.2em] mt-1 font-medium">Egypt Journey 2026</p>
          </div>
          <div className="p-2 bg-white rounded-full border border-[#E0D7D1] shadow-sm">
            <NavIcon className="w-5 h-5 text-[#8D6E63]" />
          </div>
        </div>
      </header>

      <main className="pb-32">
        <AnimatePresence mode="wait">
          {renderContent()}
        </AnimatePresence>
      </main>

      {/* Bottom Navigation */}
      <nav className="fixed bottom-8 left-1/2 -translate-x-1/2 w-[94%] max-w-md z-40">
        <div className="bg-[#3D2B1F]/95 backdrop-blur-lg rounded-full p-1.5 flex gap-1 shadow-2xl shadow-[#3D2B1F]/30">
          <button 
            onClick={() => setActiveTab('itinerary')}
            className={`flex-1 flex flex-col items-center justify-center py-2.5 rounded-full transition-all ${
              activeTab === 'itinerary' ? 'bg-white text-[#3D2B1F]' : 'text-[#D7CCC8]'
            }`}
          >
            <Calendar className="w-4 h-4 mb-0.5" />
            <span className="text-[10px] font-bold">行程</span>
          </button>
          <button 
            onClick={() => setActiveTab('flights')}
            className={`flex-1 flex flex-col items-center justify-center py-2.5 rounded-full transition-all ${
              activeTab === 'flights' ? 'bg-white text-[#3D2B1F]' : 'text-[#D7CCC8]'
            }`}
          >
            <Plane className="w-4 h-4 mb-0.5" />
            <span className="text-[10px] font-bold">航班</span>
          </button>
          <button 
            onClick={() => setActiveTab('hotels')}
            className={`flex-1 flex flex-col items-center justify-center py-2.5 rounded-full transition-all ${
              activeTab === 'hotels' ? 'bg-white text-[#3D2B1F]' : 'text-[#D7CCC8]'
            }`}
          >
            <Hotel className="w-4 h-4 mb-0.5" />
            <span className="text-[10px] font-bold">住宿</span>
          </button>
          <button 
            onClick={() => setActiveTab('emergency')}
            className={`flex-1 flex flex-col items-center justify-center py-2.5 rounded-full transition-all ${
              activeTab === 'emergency' ? 'bg-white text-[#3D2B1F]' : 'text-[#D7CCC8]'
            }`}
          >
            <Phone className="w-4 h-4 mb-0.5" />
            <span className="text-[10px] font-bold">緊急</span>
          </button>
        </div>
      </nav>
    </div>
  );
}

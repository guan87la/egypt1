import { 
  MapPin, 
  Utensils, 
  Bus, 
  Plane, 
  Hotel, 
  Phone, 
  Languages, 
  Info,
  Star,
  Camera,
  ShoppingBag,
  AlertCircle
} from 'lucide-react';

export type ActivityType = 'attraction' | 'restaurant' | 'transport' | 'hotel' | 'shopping';

export interface Activity {
  id: string;
  time?: string;
  type: ActivityType;
  title: string;
  description?: string;
  tips?: string[];
  highlights?: {
    mustEat?: string[];
    mustOrder?: string[];
    mustBuy?: string[];
    bookingCode?: string;
  };
  story?: string;
}

export interface DayPlan {
  date: string;
  title: string;
  activities: Activity[];
}

export const ITINERARY: DayPlan[] = [
  {
    date: '3/28',
    title: '開羅初探：古文明與市集',
    activities: [
      {
        id: '1-1',
        type: 'attraction',
        title: '埃及博物館 (老館)',
        description: '位於解放廣場，收藏了大量的古埃及文物。',
        story: '老博物館建於1901年，是新古典主義風格的傑作。這裡最著名的莫過於圖坦卡門的黃金面具，由11公斤純金打造。館內還有著名的「拉美西斯二世」木乃伊（需額外門票）。',
        tips: ['建議請導遊講解，否則文物眾多容易走馬看花', '黃金面具展廳禁止拍照', '館內沒有空調，下午會比較悶熱'],
        highlights: {
          mustBuy: ['博物館限定明信片']
        }
      },
      {
        id: '1-2',
        type: 'attraction',
        title: '洞穴教堂 (Sama\'an el-Kharraz)',
        description: '位於垃圾城上方，是中東最大的教堂之一。',
        story: '這座教堂是直接在穆卡塔姆山的岩石中雕刻出來的，可容納超過兩萬人。它見證了開羅「拾荒者」社群的信仰力量。前往途中會經過著名的垃圾城，是觀察當地生活的重要窗口。',
        highlights: {
          bookingCode: '建議包車前往，司機需熟悉垃圾城路線'
        }
      },
      {
        id: '1-3',
        type: 'attraction',
        title: '聖色爾爵及巴克斯教堂',
        description: '開羅最古老的科普特教堂之一。',
        story: '傳說聖家（耶穌一家）在逃往埃及时曾在此避難。',
        tips: ['進入教堂需穿著莊重', '地窖是神聖的地點']
      },
      {
        id: '1-4',
        type: 'shopping',
        title: '哈利利市場 (Khan el-Khalili)',
        description: '充滿異國情調的古老市集。',
        story: '自14世紀以來就是開羅的商業中心，迷宮般的巷弄充滿香料與手工藝品。',
        highlights: {
          mustBuy: ['香精油', '紙莎草畫', '香料', '銅製品'],
          mustEat: ['Koshary (埃及國民美食)']
        },
        tips: ['一定要殺價，從3折開始砍', '注意隨身財物']
      }
    ]
  },
  {
    date: '3/29',
    title: '金字塔之巔與新館',
    activities: [
      {
        id: '2-1',
        type: 'attraction',
        title: '吉薩金字塔群',
        description: '世界七大奇蹟之一，包含胡夫、卡夫拉、門卡拉金字塔。',
        story: '胡夫金字塔由約230萬塊巨石組成，每塊平均重2.5噸。它是世界上最高的人造建築紀錄保持者長達3800年。獅身人面像則守護在旁，象徵著法老的智慧與力量。',
        tips: ['早上前往人較少', '騎駱駝要先談好價格含小費', '進入金字塔內部非常狹窄且悶熱，有幽閉恐懼症者慎入'],
        highlights: {
          bookingCode: '現場購票或線上預約'
        }
      },
      {
        id: '2-2',
        type: 'restaurant',
        title: '米娜宮 (Mena House) 午餐',
        description: '在金字塔腳下的歷史酒店享受午餐。',
        story: '這家酒店曾接待過邱吉爾、尼克森等名人。在 139 Pavilion 餐廳用餐，金字塔就在你眼前，是開羅最奢華的視覺饗宴。',
        highlights: {
          mustOrder: ['Mixed Grill', 'Egyptian Mezze', 'Om Ali (埃及傳統甜點)'],
          bookingCode: '建議提前兩週預約窗邊位'
        }
      },
      {
        id: '2-3',
        type: 'attraction',
        title: '大埃及博物館 (GEM)',
        description: '全球最大的考古博物館。',
        story: '目前部分開放，其建築設計融合了現代與古埃及元素。',
        tips: ['目前僅開放大廳及部分展區', '建築本身就是藝術品']
      },
      {
        id: '2-4',
        type: 'shopping',
        title: '家樂福 (Carrefour)',
        description: '採買補給品與伴手禮的好地方。',
        highlights: {
          mustBuy: ['埃及茶包', '椰棗乾', '當地零食']
        }
      }
    ]
  },
  {
    date: '3/30',
    title: '黑白沙漠冒險 (Day 1)',
    activities: [
      {
        id: '3-1',
        type: 'transport',
        title: '導遊接送 (07:00)',
        description: '前往黑白沙漠。',
        tips: ['路程較長，建議準備暈車藥', '準備好輕便的過夜包']
      },
      {
        id: '3-2',
        type: 'attraction',
        title: '水晶山 (Crystal Mountain)',
        description: '由方解石晶體組成的山丘。',
        story: '這其實是一個古老的洞穴頂部坍塌後形成的景觀。'
      },
      {
        id: '3-3',
        type: 'attraction',
        title: '黑白沙漠滑沙與露營',
        description: '體驗滑沙，晚上在星空下露營。',
        highlights: {
          mustEat: ['營火烤雞']
        },
        tips: ['沙漠夜晚溫差大，需準備保暖衣物', '手機訊號極弱']
      }
    ]
  },
  {
    date: '3/31',
    title: '沙漠日出與飛往盧克索',
    activities: [
      {
        id: '4-1',
        type: 'attraction',
        title: '沙漠日出與溫泉',
        description: '在沙漠中迎接第一道曙光，並體驗天然溫泉。'
      },
      {
        id: '4-2',
        type: 'transport',
        title: '返回開羅機場 (17:00)',
        description: '準備搭乘國內線。'
      },
      {
        id: '4-3',
        type: 'transport',
        title: '飛行：開羅 -> 盧克索',
        description: '23:30 起飛，00:30 抵達。',
        highlights: {
          bookingCode: '請確認電子機票'
        }
      }
    ]
  },
  {
    date: '4/1',
    title: '盧克索：帝王之谷',
    activities: [
      {
        id: '5-1',
        type: 'attraction',
        title: '熱氣球體驗 (04:00)',
        description: '從空中俯瞰盧克索西岸。',
        tips: ['非常早起，建議前晚早睡', '帶件薄外套'],
        highlights: {
          bookingCode: '需提前與當地代理確認'
        }
      },
      {
        id: '5-2',
        type: 'attraction',
        title: '帝王谷 (Valley of the Kings)',
        description: '古埃及新王國時期法老的陵墓群。',
        story: '這裡有超過60座陵墓，包括著名的圖坦卡門陵墓。',
        tips: ['一張票可參觀三個陵墓', '賽提一世陵墓需額外購票']
      },
      {
        id: '5-3',
        type: 'attraction',
        title: '哈布城 (Medinet Habu)',
        description: '拉美西斯三世的祭廟。',
        story: '以其保存完好的深浮雕而聞名，色彩依然鮮豔。'
      },
      {
        id: '5-4',
        type: 'attraction',
        title: '尼羅河帆船 (Felucca)',
        description: '悠閒地在尼羅河上航行。',
        tips: ['傍晚時分最美']
      }
    ]
  },
  {
    date: '4/2',
    title: '神廟壯麗與前往紅海',
    activities: [
      {
        id: '6-1',
        type: 'attraction',
        title: '卡納克神廟 (Karnak Temple)',
        description: '埃及最大的神廟建築群。',
        story: '其大柱廳有134根巨大的石柱，壯觀無比。',
        tips: ['園區非常大，建議預留至少2-3小時']
      },
      {
        id: '6-2',
        type: 'shopping',
        title: 'El-Souk 市集',
        description: '盧克索當地的傳統市集。'
      },
      {
        id: '6-3',
        type: 'restaurant',
        title: '盧克索麥當勞',
        description: '擁有「全球最美景觀」的麥當勞之一。',
        highlights: {
          mustBuy: ['盧克索限定大浴巾']
        }
      },
      {
        id: '6-4',
        type: 'attraction',
        title: '盧克索神廟',
        description: '位於市中心，夜晚點燈後非常迷人。'
      },
      {
        id: '6-5',
        type: 'transport',
        title: 'GOBUS 前往赫爾格達',
        description: '19:30 發車，23:30 抵達。',
        highlights: {
          bookingCode: '請提前取票'
        }
      }
    ]
  },
  {
    date: '4/3',
    title: '赫爾格達：紅海潛水',
    activities: [
      {
        id: '7-1',
        type: 'attraction',
        title: '出海潛水 (09:00 - 16:00)',
        description: '在紅海清澈的海水中探索珊瑚礁。',
        tips: ['準備好防曬乳（海洋友善）', '帶好泳衣與毛巾']
      },
      {
        id: '7-2',
        type: 'shopping',
        title: '赫爾格達逛街',
        description: '享受紅海度假勝地的悠閒氛圍。'
      }
    ]
  },
  {
    date: '4/4',
    title: '沙漠飆沙與觀星',
    activities: [
      {
        id: '8-1',
        type: 'attraction',
        title: 'ATV 飆沙與觀星',
        description: '騎乘沙灘車深入沙漠，觀賞壯麗星空。',
        tips: ['風沙大，建議準備魔術頭巾與護目鏡']
      },
      {
        id: '8-2',
        type: 'transport',
        title: 'GOBUS 返回開羅',
        description: '23:57 發車。',
        highlights: {
          bookingCode: '夜車建議準備頸枕'
        }
      }
    ]
  },
  {
    date: '4/5',
    title: '歸途',
    activities: [
      {
        id: '9-1',
        type: 'transport',
        title: '抵達開羅 Nasr City (06:00)',
        description: '最後的市區巡禮。'
      },
      {
        id: '9-2',
        type: 'transport',
        title: '開羅機場起飛 (13:30)',
        description: '帶著滿滿回憶回台灣。'
      }
    ]
  }
];

export const INFO = {
  flights: [
    {
      route: 'Cairo -> Luxor',
      time: '3/31 23:30 - 00:30',
      airline: 'EgyptAir',
      code: 'MSxxx'
    },
    {
      route: 'Cairo -> Taiwan',
      time: '4/5 13:30',
      airline: 'TBD',
      code: 'TBD'
    }
  ],
  accommodations: [
    {
      name: '開羅飯店',
      date: '3/28 - 3/30',
      address: 'TBD'
    },
    {
      name: '黑白沙漠露營',
      date: '3/30 - 3/31',
      address: 'Black & White Desert'
    },
    {
      name: '盧克索飯店',
      date: '3/31 - 4/2',
      address: 'TBD'
    },
    {
      name: '赫爾格達飯店',
      date: '4/2 - 4/4',
      address: 'TBD'
    }
  ],
  emergency: [
    { label: '台灣駐約旦代表處 (兼轄埃及)', number: '+962-79-555-2447' },
    { label: '埃及報警', number: '122' },
    { label: '埃及救護車', number: '123' },
    { label: '埃及旅遊警察', number: '126' }
  ]
};
